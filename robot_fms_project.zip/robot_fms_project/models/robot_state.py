import threading
import time
import random

class RobotMockManager:
    def __init__(self):
        # UI 이미지(SEONGSU_03) 기반 초기 상태 세팅
        self.state = {
            "robot_id": "SEONGSU_03",
            "location": {"floor": "B1F", "x": 120.5, "y": 45.2},
            "status": "idle",  # 상태: idle, moving, error 등
            "speed": 0.0,
            "battery_percent": 98.0,
            "battery_voltage": 49.0,
            "cpu_usage": 2.0,
            "memory_usage": 33.0,
            "latency_total": 55,
            "latency_robot": 93
        }
        self.running = True
        # 백그라운드에서 데이터를 지속적으로 갱신하는 데몬 스레드 실행
        self.thread = threading.Thread(target=self._update_mock_data, daemon=True)
        self.thread.start()

    def _update_mock_data(self):
        """실제 하드웨어의 동작을 흉내 내기 위해 1초마다 상태 값을 미세하게 변동시킴"""
        while self.running:
            time.sleep(1) 
            
            # 이동 중일 때 배터리 소모 및 좌표 변경
            if self.state["status"] == "moving":
                if self.state["battery_percent"] > 0:
                    self.state["battery_percent"] -= random.uniform(0.01, 0.05)
                
                # 가상의 방향으로 좌표 이동
                self.state["location"]["x"] += random.uniform(-0.5, 0.5)
                self.state["location"]["y"] += random.uniform(-0.5, 0.5)
                self.state["speed"] = round(random.uniform(0.8, 1.2), 2)
            else:
                self.state["speed"] = 0.0

            # CPU, 메모리, 네트워크 레이턴시에 자연스러운 노이즈 추가
            self.state["cpu_usage"] = round(random.uniform(1.0, 15.0), 1)
            self.state["memory_usage"] = round(random.uniform(30.0, 35.0), 1)
            self.state["latency_total"] = int(random.uniform(40, 80))
            self.state["latency_robot"] = int(random.uniform(80, 120))

    def get_state(self):
        """현재 로봇의 상태(JSON 직렬화 가능 형태)를 반환"""
        # 배터리 등 소수점 데이터 포맷팅
        state_copy = self.state.copy()
        state_copy["battery_percent"] = round(state_copy["battery_percent"], 1)
        return state_copy

    def update_command(self, command):
        """프론트엔드(UI)에서 전달된 제어 명령 처리"""
        action = command.get("action")
        
        if action == "move":
            self.state["status"] = "moving"
        elif action == "stop":
            self.state["status"] = "idle"
        elif action == "charge":
            # 충전소 이동 명령 시 배터리 회복 시뮬레이션용 상태 전환
            self.state["status"] = "idle"
            self.state["battery_percent"] = 100.0
            
        return {"status": "success", "message": f"명령 '{action}'(이)가 성공적으로 반영되었습니다."}

# 앱 전체에서 하나의 상태를 공유하기 위해 싱글톤 패턴처럼 인스턴스 생성
robot_manager = RobotMockManager()
