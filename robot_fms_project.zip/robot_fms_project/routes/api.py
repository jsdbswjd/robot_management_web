from flask import Blueprint, jsonify, request
from models.robot_state import robot_manager  # 완성하신 모델 불러오기

api_bp = Blueprint('api', __name__)

# 1. 로봇 상태 정보 주기 (GET)
@api_bp.route('/robot/status', methods=['GET'])
def get_status():
    status = robot_manager.get_state()
    return jsonify(status)

# 2. 로봇 제어 명령 받기 (POST)
@api_bp.route('/robot/control', methods=['POST'])
def control_robot():
    command = request.json  # JS에서 보낸 {"action": "move"} 형태의 데이터
    result = robot_manager.update_command(command)
    return jsonify(result)

# 3. 로그 정보 주기 (필요 시)
@api_bp.route('/logs', methods=['GET'])
def get_logs():
    # 간단한 예시 로그 데이터
    logs = [
        {"time": "10:30:01", "type": "정상", "message": "시스템 가동"},
        {"time": "10:30:05", "type": "주의", "message": "장애물 감지"}
    ]
    return jsonify(logs)
