from flask import Flask, render_template
from flask_cors import CORS
from routes.api import api_bp

app = Flask(__name__)
CORS(app)  # 프론트엔드와 통신 시 보안 에러 방지

# API 라우트 등록 (api.py 연결)
app.register_blueprint(api_bp, url_prefix='/api/v1')

# 메인 페이지 접속 시 index.html을 보여줌
@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    # 5000번 포트로 서버 실행
    app.run(host='0.0.0.0', port=5000, debug=True)
